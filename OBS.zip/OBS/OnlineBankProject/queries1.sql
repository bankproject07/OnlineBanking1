
DROP table User_Table;
create table User_Table
(
user_id VARCHAR2(20) primary key,
Account_ID NUMBER,
login_password VARCHAR2(15),
secret_question VARCHAR2(50),
secret_answer VARCHAR2(50),
Transaction_password VARCHAR2(15),
lock_status VARCHAR2(10),foreign key(Account_ID) references Account_Master(Account_ID) 
);

insert into USER_TABLE VALUES(12345,1789542,'abcd','sd','bd','789','L');
select * from USER_TABLE;